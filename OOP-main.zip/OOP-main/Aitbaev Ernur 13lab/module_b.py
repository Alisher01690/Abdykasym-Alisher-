from common import shared_logic

def func_b():
    return "B + " + shared_logic()
